export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "modules/brokentail_utility_belt/templates"
    ];
    return loadTemplates(templatePaths);
};
